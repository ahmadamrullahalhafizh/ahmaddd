const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const app = express();

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
  secret: 'rahasia',
  resave: false,
  saveUninitialized: true
}));

// Import routes
const authRoutes = require('./routes/auth');
const mahasiswaRoutes = require('./routes/mahasiswa');

// Gunakan routes
app.use('/', authRoutes);
app.use('/mahasiswa', mahasiswaRoutes);

// ✅ Tambahkan route utama
app.get('/', (req, res) => {
  if (req.session.loggedIn) {
    res.redirect('/mahasiswa');
  } else {
    res.redirect('/login');
  }
});

// Jalankan server
app.listen(3000, () => console.log('Server berjalan di http://localhost:3000'));
