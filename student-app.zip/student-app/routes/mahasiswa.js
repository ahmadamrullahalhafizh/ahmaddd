const express = require('express');
const router = express.Router();
const db = require('../db');

// Middleware auth
router.use((req, res, next) => {
  if (!req.session.loggedIn) return res.redirect('/login');
  next();
});

// Tampilkan semua mahasiswa + filter
router.get('/', (req, res) => {
  const search = req.query.search || '';
  db.query("SELECT * FROM mahasiswa WHERE nama LIKE ?", [`%${search}%`], (err, results) => {
    if (err) throw err;
    res.render('mahasiswa/index', { mahasiswa: results, search });
  });
});

// Form tambah
router.get('/add', (req, res) => {
  res.render('mahasiswa/add');
});

// Proses tambah
router.post('/add', (req, res) => {
  const { nama, nim, jurusan } = req.body;
  db.query("INSERT INTO mahasiswa SET ?", { nama, nim, jurusan }, () => {
    res.redirect('/mahasiswa');
  });
});

// Form edit
router.get('/edit/:id', (req, res) => {
  db.query("SELECT * FROM mahasiswa WHERE id = ?", [req.params.id], (err, results) => {
    if (err) throw err;
    res.render('mahasiswa/edit', { mhs: results[0] });
  });
});

// Proses edit
router.post('/edit/:id', (req, res) => {
  const { nama, nim, jurusan } = req.body;
  db.query("UPDATE mahasiswa SET nama=?, nim=?, jurusan=? WHERE id=?", [nama, nim, jurusan, req.params.id], () => {
    res.redirect('/mahasiswa');
  });
});

// Hapus
router.get('/delete/:id', (req, res) => {
  db.query("DELETE FROM mahasiswa WHERE id=?", [req.params.id], () => {
    res.redirect('/mahasiswa');
  });
});

module.exports = router;
